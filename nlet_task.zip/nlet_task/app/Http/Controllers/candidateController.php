<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\candidateModel;
use Validator;
use Storage;

class candidateController extends Controller
{
    private function __imageSave($request, $key = '', $folder_name = '', $old_img = '')
    {
        $fileName = "";
        if ($request->hasFile($key) && !empty($key) && !empty($folder_name)) {
            $image = $request->file($key);
            $OriginalName = $image->getClientOriginalName();
            $fileName = time() . '.' . $OriginalName;
            $request->file($key)->storeAs('public/' . $folder_name . '/', $fileName);
            if (!empty($old_img)) {
                if (Storage::exists('public/' . $folder_name . '/', $old_img)) {
                    Storage::delete('public/' . $folder_name . '/' . $old_img);
                }
            }
        }

        return $fileName;
    }
    public function add_candidate(Request $request)
    {
        // Validation rules
        $rules = [
            'first_name' => 'required|max:40',
            'last_name' => 'required',
            'email' => 'required|email|unique:candidates',
            // 'contact_number' => 'required|max:10|contact_number|unique:candidates',
            'gender' => 'required',
            'specialization' => 'required',
            'work_ex_year' => 'required',
            'candidate_dob' => 'required',
        ];

        // Validate the request data
        $validator = Validator::make($request->all(), $rules);

        // Check if validation fails
        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }
        $fileName = null;
        if($request->resume){
        $fileName = $this->__imageSave($request, 'resume', 'candidate-images');
        }
        $candidateData = [
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'email' => $request->email,
            'contact_number' => $request->contact_number,
            'gender' => $request->gender,
            'specialization' => $request->specialization,
            'work_ex_year' => $request->work_ex_year,
            'candidate_dob' => $request->candidate_dob,
            'address' => $request->address,
            'resume' =>$fileName,
        ];

        $insert = candidateModel::create($candidateData);
        if ($insert) {
            $success['status'] = '201';
            $success['first_name'] = $insert->first_name;
            $success['last_name'] = $insert->last_name;
            $success['email'] = $insert->email;
            $success['contact_number'] = $insert->contact_number;
            $success['gender'] = $insert->gender;
            $success['specialization'] = $insert->specialization;
            $success['work_ex_year'] = $insert->work_ex_year;
            $success['candidate_dob'] = $insert->candidate_dob;
            $success['address'] = $insert->address;
            $success['resume'] = $insert->resume;
            return $this->sendResponse($success, 'Candidate Add Successfully.');
        } else {
            return $this->sendError(['error' => 'Something want wrong']);
        }
    }

    public function candidate($id)
    {
        $data = candidateModel::where('id', $id)->first();
        if ($data) {
            // return $this->sendResponse($data, 'Successfully.');
            return response()->json($data);
        } else {
            $success['status'] = '404';
            return $this->sendResponse($success, 'Data not found');
        }
    }

    public function candidate_data(Request $request)
    {
        $perPage = $request->input('limit', 10);
        $query = candidateModel::query();
        if ($request->first_name) {
            $query->where('first_name', $request->first_name);
        }

        if ($request->last_name) {
            $query->where('last_name', $request->last_name);
        }
        if ($request->email) {
            $query->where('email', $request->email);
        }

        // Paginate the results based on the 'page' parameter
        $page = $request->input('page', 1);
        $candidateData = $query->paginate($perPage, ['*'], 'page', $page);
        // $candidateData = $query->paginate($perPage);

        if ($candidateData->isEmpty()) {
            $success['status'] = '404';
            return $this->sendResponse($success, 'Data not found');
        }
        $currentPage = $candidateData->currentPage();
        $totalItems = $candidateData->total();
        $itemsPerPage = $candidateData->perPage();
        $lastPage = $candidateData->lastPage();
        $data = $candidateData->items();
        $firstPageUrl = $candidateData->url(1);
        $nextPageUrl = $candidateData->nextPageUrl();
        $path = $candidateData->path();
        $prevPageUrl = $candidateData->previousPageUrl();
        $from = $candidateData->firstItem();
        $to = $candidateData->lastItem();

        return response()->json([
            'current_page' => $currentPage,
            'first_page_url' => $firstPageUrl,
            'from' => $from,
            'next_page_url' => $nextPageUrl,
            'path' => $path,
            'per_page' => $itemsPerPage,
            'prev_page_url' => $prevPageUrl,
            'to' => $to,
            'total' => $totalItems,
            'last_page' => $lastPage,
            'data' => $data,
        ]);
    }
}
